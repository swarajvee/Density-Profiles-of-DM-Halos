import matplotlib.pyplot as plt
from colossus.cosmology import cosmology

h= 0.6736
params={'flat':True,'Om0':0.315192, 'Ob0':0.02237/h**2, 'H0': 67.36, 'sigma8':0.8, 'ns':0.9649, 'relspecies':True, 'Tcmb0':2.7255,'Neff': 3.04}

cosmology.setCosmology('My_Cosmo',**params)

