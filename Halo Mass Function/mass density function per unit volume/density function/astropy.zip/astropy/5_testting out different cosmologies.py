from astropy.cosmology import FlatLambdaCDM
import numpy as np 
import matplotlib.pyplot as plt 



h= 0.6736
sigma8= 0.807952  
ns= 0.9649
#relspecies=True
Ode0= 0.684808
M = 10**np.arange(10.93, 12.3, 0.1)
params={'Om0':0.315192, 'Ob0':0.02237/h**2, 'H0':67.36, 'Tcmb0':2.7255, 'Neff': 3.04}
cosmo= FlatLambdaCDM(**params)
halo_MF = cosmo
#print(cosmo)
