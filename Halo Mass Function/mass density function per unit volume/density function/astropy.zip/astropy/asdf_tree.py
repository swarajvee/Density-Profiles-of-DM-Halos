import asdf
af = asdf.open("/Users/swarajv/Education/s10 MSc Major Project/Hubble data/z8.000/halo_info/halo_info_000.asdf",copy_arrays=True)
af.info(max_rows=None, max_cols=None)