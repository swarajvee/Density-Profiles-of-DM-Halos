import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
fig=plt.figure(figsize=(10,8),dpi=100)
from colossus.lss import mass_function
from colossus.cosmology import cosmology
import astropy.cosmology

def MassFunc(z,M,Om0,Ob0,H0,sigma8,ns,Tcmb0,Neff):
    params={'Om0':Om0, 'Ob0':Ob0, 'H0':H0, 'Tcmb0':Tcmb0, 'Neff': Neff}
    astropy_cosmo= astropy.cosmology.FlatLambdaCDM(**params)
    colossus_cosmo= cosmology.fromAstropy(astropy_cosmo, sigma8, ns, cosmo_name='My_Cosmo')
    mfunc = mass_function.massFunction(M, z, mdef = '200m', model = 'tinker08', q_out ='dndlnM')
    plt.loglog()
    plt.plot(M, 2.303*(mfunc/M),'--', label = 'Mass Density using Colossus Package', alpha=0.2, color='red')
    plt.grid()
    plt.show()


#for colossus 
z = 8.072500247186802 #redshift
M = 10**np.arange(11.0, 12.3, 0.1)

#cosmological parameters
h= 0.6736
Om0= 0.315192
Ob0= 0.02237/h**2
H0= 67.36
sigma8= 0.807952
ns= 0.9649
Tcmb0= 2.7255
Neff= 3.04

Ocdm0= 0.12/h**2

MassFunc(z,M,Om0,Ob0,H0,sigma8,ns,Tcmb0,Neff)