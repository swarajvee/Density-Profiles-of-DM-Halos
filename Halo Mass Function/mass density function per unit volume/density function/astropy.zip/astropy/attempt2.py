from astropy import cosmology
help(cosmology)