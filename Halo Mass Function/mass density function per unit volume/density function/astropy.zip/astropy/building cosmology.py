import numpy as np 
import matplotlib.pyplot as plt 
fig= plt.figure(figsize=(10,8),dpi=100)
import astropy.cosmology
import astropy.units as u

h= 0.6736
params = dict(H0= 67.36*u.km/u.s/u.Mpc ,Om0= 0.315192, Ob0= 0.02237/h**2, Tcmb0= 2.7255,Neff= 3.04)
sigma8= 0.807952
ns= 0.9649
Ode0= 0.684808 #dark energy density
z = 8.072500247186802 #redshift
M = 10**np.arange(11.0, 12.3, 0.1)


astropy_cosmo= astropy.cosmology.FlatLambdaCDM(**params)
zvals = np.arange(0, 6, 0.1)
dist = astropy_cosmo.angular_diameter_distance(zvals)
plt.plot(zvals,dist)
plt.grid()
plt.show()