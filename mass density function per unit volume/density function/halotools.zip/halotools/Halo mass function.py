import numpy as np
import matplotlib.pyplot as plt
from halotools.sim_manager import CachedHaloCatalog
from halotools.mock_observables import halo_mass_function

# Load a halo catalog
halo_catalog = CachedHaloCatalog(simname='bolshoi', redshift=0, halo_finder='rockstar')

# Define the mass bins
mass_bins = np.logspace(10, 15, 30)

# Calculate the halo mass function
mass_function_result = halo_mass_function(halo_catalog.halo_table['halo_mvir'], mass_bins, volume=halo_catalog.Lbox[0]**3)

# Plot the results
plt.plot(np.log10(mass_bins[:-1]), np.log10(mass_function_result), marker='o')
plt.xlabel('log10(Mass)')
plt.ylabel('log10(Number density)')
plt.title('Halo Mass Function')
plt.show()
