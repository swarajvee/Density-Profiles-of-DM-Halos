from halotools.empirical_models import PrebuiltSubhaloModelFactory
import numpy as np
from halotools.sim_manager import CachedHaloCatalog #for halocat

def halo_mass_function(z,Om0,Ob0,H0,sigma8,ns,Tcmb0,Neff,Ode0):
    params={'redshift': z,'flat':False,'Om0':Om0, 'Ob0':Ob0, 'H0':H0, 'sigma8':sigma8, 'ns':ns, 'relspecies':True, 'Tcmb0':Tcmb0, 'Neff': Neff, 'Ode0':Ode0}
    model = PrebuiltSubhaloModelFactory('behroozi10',**params)
    
    # Select a halo catalog
    halocat = CachedHaloCatalog(simname='bolshoi', redshift=z, halo_finder='rockstar')
    #help(model)

z = 8.072500247186802 #redshift
M = 10**np.arange(10.93, 12.3, 0.1)

#cosmological parameters
h= 0.6736
Om0= 0.315192
Ob0= 0.02237/h**2
H0= 67.36
sigma8= 0.807952
ns= 0.9649
Tcmb0= 2.7255
Neff= 3.04
Ode0= 0.684808

Ocdm0= 0.12/h**2

halo_mass_function(z,Om0,Ob0,H0,sigma8,ns,Tcmb0,Neff,Ode0)