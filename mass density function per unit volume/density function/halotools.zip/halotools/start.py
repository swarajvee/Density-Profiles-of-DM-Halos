from halotools.empirical_models import PrebuiltSubhaloModelFactory
from halotools.empirical_models import Behroozi10SmHm
from halotools.sim_manager import FakeSim
import numpy as np 


def Behroozil_model(halo_mass,redshift):
    halocat = FakeSim()
    model = PrebuiltSubhaloModelFactory('behroozi10')
    model.populate_mock(halocat)  

    
    params1 = {'prim_haloprop': halo_mass, 'redshift': redshift}
    mean_sm = model.mean_stellar_mass(**params1)
    return mean_sm

    '''params= {"redshift": 8}
    sm_model = Behroozi10SmHm(**params)
    #model_instance = SubhaloModelFactory()'''

halo_mass = np.logspace(11, 15, 100)
redshift= 8

Behroozil_model(halo_mass,redshift)